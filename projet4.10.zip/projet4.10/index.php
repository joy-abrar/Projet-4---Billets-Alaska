<?php 
	include('controller/controller_user.php');
	include('controller/controller_admin.php');

	$controls_user = new Controls_User();
	$controls_admin = new Controls_Admin();


	if (isset($_GET['action'])) 
	{
	
		if ($_GET['action'] == 'accueil') 
		{
			$controls_user -> homepage();
			
		}

		if ($_GET['action'] == 'biographie') 
		{
			$controls_user -> biographie();
			
		}

		if ($_GET['action'] == 'billets') 
		{
			$controls_user -> billets();
			 
		}

		if ($_GET['action'] == 'contact') 
		{
			$controls_user -> contact();
			
		}
	
		if ($_GET['action'] == 'all_articles') 
		{
			$controls_user -> billets();
		}

		if ($_GET['action'] == 'aboutus') 
		{
			$controls_user -> apropos();
		}

		if ($_GET['action'] == 'connect') 
		{
			$controls_user -> login();
		}

		if ($_GET['action'] == 'disconnect') 
		{
			$controls_admin -> disconnect();
		}

		if ($_GET['action'] == 'returnToArticles') 
		{
			$controls_user -> billets();
		}

		if ($_GET['action'] == 'readMore') 
		{
			$controls_user -> readMore();
		}

		if ($_GET['action'] == 'viewMore') 
		{
			$controls_user -> viewMore();
		}

		if ($_GET['action'] == 'editThisArticle') 
		{
			$controls_admin -> editThisArticle($_GET['id'] , $_GET['title']);
			//$_GET["id"];
			//$_GET["title"];
			//$_GET["para"];
			//die();
		}

		if ($_GET['action'] == 'deleteThisArticle') 
		{
			$controls_admin -> deleteThisArticle();
			//$_GET["id"];
			//$_GET["title"];
			//$_GET["para"];
			//die();
		}

		if ($_GET['action'] == 'deletingArticleFormConfirmed') 
		{
			$controls_admin -> deletingArticleFormConfirmed();
		}

		if ($_GET['action'] == 'deletingArticleFormDenied') 
		{
			$controls_admin -> deletingArticleFormDenied();
		}

		if ($_GET['action'] == 'postThisComment') 
		{
			//var_dump('toto');
			//var_dump($_POST['username']);
			//var_dump($_POST['userComment']);
			//die();
			$controls_user -> postThisComment();
		}		
	}



	else
		{
			$controls_user -> homepage();
		}

?>