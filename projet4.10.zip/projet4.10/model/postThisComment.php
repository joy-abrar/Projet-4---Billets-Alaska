<?php

	include('databaseConnection.php');

	$query = "INSERT INTO comments  WHERE articleid = '1' ";
	$run = mysqli_query($connect , $query);
	
	//echo $_GET['username'];
?>