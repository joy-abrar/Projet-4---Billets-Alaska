
<?php
	include('../templates/menubar.php');
	include('../model/databaseConnection.php');
	$query = "SELECT * FROM articles";
	$run = mysqli_query($connect , $query);
?>


<!DOCTYPE html>
<html>
<head>
	<title>Articles From DataBase</title>
</head>
<body>


		<?php
			session_start();
			while ($rows=mysqli_fetch_assoc($run)) 
			{

				$_SESSION["idSelected"] = $rows['id'];
				$_SESSION["titleSelected"] = $rows['Title'];
				$_SESSION["paragraphSelected"] = $rows['Paragraph'];
		?>
				<div id="recentArticles">
					<div id="firstArticle" name="firstArticle">
						<h3 id="firstArticleHeadTitle"><?php echo $rows['Title'];?></h3>
						<h3 id="firstArticleHeadTitle">Publié le <?php echo $rows['date'];?></h3>
						<center>
							<a href="../index.php?action=editThisArticle&amp;id=<?= $rows['id'] ?>&amp;title=<?= $rows['Title'] ?>&amp;para=<?= $rows['Paragraph'] ?>">EDIT</a>
							<a href="../index.php?action=deleteThisArticle&amp;id=<?= $rows['id'] ?>&amp;title=<?= $rows['Title'] ?>&amp;para=<?= $rows['Paragraph'] ?>">DELETE</a>

						</center>
					</div>
				</div>
		<?php
			}
		?>
	</table>

	<footer>
		<?php
			include('../templates/footer.php');
		?>
	</footer>
</body>
</html>
