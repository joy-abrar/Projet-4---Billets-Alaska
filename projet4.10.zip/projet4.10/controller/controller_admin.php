<?php

class Controls_Admin
{

	function loggedIn()
	{
		header("location:../view/adminLoggedIn.php");
	}

	function disconnect()
	{
		header("location:././index.php");
	}

	function editThisArticle($id , $title)
	{
		
		include('././view/updatingArticleForm.php');
		//header("location:././view/updatingArticleForm.php");
		//$_GET["id"];
		//$_GET["title"];
		//$_GET["para"];
		//$_GET['title'] = var_dump($_GET["title"]);
		//$_GET['para'] = var_dump($_GET["para"]);
		//echo $_GET['title'];
		//die();
	}

	function deleteThisArticle()
	{
		include('././view/deletingArticleForm.php');
		//header("location:././view/deletingArticleForm.php");
		//$_GET["id"];
		//$_GET["title"];
		//$_GET["para"];
		//$_GET['title'] = var_dump($_GET["title"]);
		//$_GET['para'] = var_dump($_GET["para"]);
		//echo $_GET['title'];
		//die();
	}

	function deletingArticleFormConfirmed()
	{
		header('location:././view/deletingArticleFormConfirmed.php');
	}

	function deletingArticleFormDenied()
	{
		header('location:././view/billets.php');
	}
}

?>