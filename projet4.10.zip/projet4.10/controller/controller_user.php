<?php


class Controls_User
{	
	function startupRun()
	{
		include('./view/homepage.php');
	}

	function homepage()
	{
		header('location:./view/homepage.php');
	}

	function biographie()
	{
		header('location:./view/biographie.php');
	}


	function billets()
	{
		header('location:./view/billets.php');
	}


	function contact()
	{
		header('location:./view/contact.php');
	}

	function apropos()
	{
		header('location:./view/aboutus.php');
	}

	function login()
	{
		header('location:./view/loginform.php');
	}

	function readMore()
	{
		header('location:./view/readMore.php');
	}

	function viewMore()
	{
		header('location:./view/viewMore.php');
	}

	function postThisComment()
	{
		include('./model/postThisComment.php');
	}
}

?>