<head>
	<link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>
<?php
	include('../templates/menubar.php');
?>


<?php
	include('../model/databaseConnection.php');
	$query = "SELECT * FROM articles ORDER BY id DESC LIMIT 1";
	$run = mysqli_query($connect , $query);
?>

		<?php
			while ($rows = mysqli_fetch_assoc($run)) 
			{
				$_SESSION['id'] = $rows['id'];
				$_SESSION['mentionId'] = $rows['id'];
		?>
	<div id="recentArticles">
		<div id="firstArticle" name="firstArticle">
			<h3 id="firstArticleHeadTitle"><?php echo $rows['Title']; ?></h3>
			<hr id="firstArticleHeaderSeperationBloc">
			<p id="firstArticleParagraphe">	<?php echo $rows['Paragraph']; ?> </p>
			<hr id="firstArticleFooterSeperationBloc">
		</div>
		<p id="firstArticleDate">	Publié le <?php echo $rows['date']; ?> </p>			
	</div>

<?php
	}
?>

<!--<a id="firstArticleComments">	Comments <?php echo $rows['date']; ?> </p>-->
<?php
	include('../model/databaseConnection.php');
	$query = "SELECT *FROM comments WHERE articleId = '1' ";
	$run = mysqli_query($connect , $query);

?>
<?php
while ($rows = mysqli_fetch_assoc($run)) 
			{
				$rows['id'];
				$rows['comment'];
?>
	<div id="recentArticles">
		<div id="firstArticle" name="firstArticle">
			<h3 id="firstArticleHeadTitle"><?php echo $rows['username']; ?></h3>
			<hr id="firstArticleHeaderSeperationBloc">
			<p id="firstArticleParagraphe">	<?php echo $rows['comment']; ?> </p>
		</div>			
	</div>

<?php
	}
?>

	<form method="GET">
		<center id="commentBoxParam">
			<h3>Ecrivez vos commentaires ici</h3>
			<h4>Nom d'utilisateur</h4>
			<input type="text" name="username" id="commentBoxUsernameParam">
			<h4>Commentaire</h4>
			<input type="text" name="userComment" id="commentBoxCommentParam">
			<br/><br/><br/>
			<center><a href="../index.php?action=postThisComment" name="postComment" id="commentBoxValidButtonParam">POSTER</a></center>
		</center>
	</form>


<?php
	if (isset($_GET['postComment'])) 
	{
		$_GET['username'];
		$_GET['userComment'];
	}
?>