<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../public/css/style.css">
	<title>VIEW MORE</title>
</head>
<body>
	<?php
		include('../templates/menubar.php');

		include('../templates/viewClickedArticle.php');

		include('../templates/footer.php');
	?>

	


<?php
	include('../model/databaseConnection.php');
	$query = "SELECT *FROM comments WHERE articleId = '1' ";
	$run = mysqli_query($connect , $query);

?>
<?php
while ($rows = mysqli_fetch_assoc($run)) 
			{
				$rows['id'];
				$rows['comment'];
?>
	<div id="recentArticles">
		<div id="firstArticle" name="firstArticle">
			<h3 id="firstArticleHeadTitle"><?php echo $rows['username']; ?></h3>
			<hr id="firstArticleHeaderSeperationBloc">
			<p id="firstArticleParagraphe">	<?php echo $rows['comment']; ?> </p>
		</div>			
	</div>

<?php
	}
?>

<center id="commentBoxParam">
		<form method="POST" action="../index.php?action=postThisComment">
			<h3>Ecrivez vos commentaires ici</h3>
			<h4>Nom d'utilisateur</h4>
			<input type="text" name="username" id="commentBoxUsernameParam">
			<h4>Commentaire</h4>
			<input type="text" name="userComment" id="commentBoxCommentParam">
			<br/><br/><br/>
			<input type="submit" id="commentBoxValidButtonParam" value="POSTER">
		</form>
	</center>



<?php
/*	if (isset($_GET['postComment'])) 
	{
		$_POST['username'];
		$_POST['userComment'];
	}
*/
?>

</body>
</html>