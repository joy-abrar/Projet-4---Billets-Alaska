<?php

	include('../templates/editArticle.php');
	include('../templates/adminManagement1.php');

?>