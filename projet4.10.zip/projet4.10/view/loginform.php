<?php
	include('../templates/menubar.php');
?>

<head>
	<link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>

<body>

<div id="loginPageBloc">
	<form method="POST" action="">
		<div id="loginBloc">
			<span><b>Identifiant</b></span>
			<input id="loginIdInput" type="text" name="loginId"/>
			<br/>
			<span><b>Mot De Passe<b></span>
			<input id="loginPasswordInput" type="password" name="loginPassword"/>
			<br/><br/>
			<input id="loginbutton" type="submit" name="loginSubmit">
		</div>
	</form>
	<?php
	include('../model/login_process.php');
	?>
</div>
</body>

<?php
	include('../templates/footer.php');
?>

