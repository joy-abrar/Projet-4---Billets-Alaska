<div id="recentArticles">
	<div id="firstArticle" name="firstArticle">
		<h3 id="firstArticleHeadTitle"><?php echo $lastPost['Title']; ?></h3>
		<hr id="firstArticleHeaderSeperationBloc">
		<p id="firstArticleParagraphe">	<?php echo $lastPost['Paragraph']; ?> </p>
		<hr id="firstArticleFooterSeperationBloc">
	</div>
	<p id="firstArticleDate">	Publié le <?php echo $lastPost['date']; ?> </p>			
	<a href="index.php?action=readMore&amp;selectedId= <?= $lastPost['id'] ?>">Lire Plus...</a>
	<p><?php echo $lastPost['commentsNb']." "."commentaires" ?></p>
</div>