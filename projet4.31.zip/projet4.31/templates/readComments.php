<?php
	include('../model/databaseConnection.php');
?>

<head>
	<link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>
<?php
?>

<div class="commentsBody1">
	<form class="commentsBody2" method="POST" action="">
		<span>Name:</span><input class="nameBox" type="text" name="name"><br>
		<span>Your Comment:</span><textarea class="commentBox" name="putYourComment"></textarea>
		<input class="postCommentButton" type="submit" name="submit">
	</form>
</div>


<?php
	if (isset($_POST['submit'])) 
	{
		$name = $_POST['name'];
		$comment = $_POST['putYourComment'];

		$query = "INSERT INTO comments (username , comment) VALUES ('$name' , '$comment')" ;
		if (mysqli_query($connect, $query)) 
		{
			$_SESSION['articleId'];
    		echo "post successfully as" . $articleId;
			
		} 
		else 
		{
    		echo "Error: " . $query . "<br>" . mysqli_error($connect);	
		}

	}
?>