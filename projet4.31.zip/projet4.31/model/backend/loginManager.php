<?php
	require_once('model/Manager.php');
	class loginManager  extends Manager
	{
		public function getLogin()
		{ 
			
			if (isset($_POST['loginSubmit'])) 
			{
				$id = $_POST['loginId'];
				$password = $_POST['loginPassword'];
				$decryptedPassword = base64_encode($password);
				$password = $decryptedPassword;
				
				$db = $this->dbConnect(); 
				$query = $db->prepare('SELECT * FROM account WHERE login = ? AND password = ?'); 
				$run = $query->execute(array($id, $password));
				
				$row = $query->fetch(PDO::FETCH_ASSOC);
				$dataId = $row['login'];
				$dataPassword = $row['password'];

				if ($run) 
				{
							
					if ($id == $dataId && $password == $dataPassword) 
					{
						$_SESSION['admin_status'] = "loggedIn";
						if ($_SESSION['admin_status'] == "loggedIn") 
						{
							$controls_admin = new Controls_Admin;
							$controls_admin -> loggedIn();	
						}

						else if ($_SESSION['admin_status'] == "loggedOut") 
						{
							$controls_user -> homepage();
						}				
					}

					else
					{ 
						echo '<center><div><h4>Wrong ID/Password Inserted! Try Again!</h4></div></center>';
					}
				}
			}
		}

		public function getLogOut() // for accurate navigation in reading post pages (2/4) 
		{
			$_SESSION['admin_status'] == "loggedOut";
			header("location:./index.php");
		}

	}


?>