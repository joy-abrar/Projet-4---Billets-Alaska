<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
	<title>Articles From DataBase</title>
</head>
<body>


		<?php
			include('menubar.php');
		?>
		<center><h1>Messages Reçu</h1></center>
		<?php
			session_start();
			while($rows = $viewMessages->fetch())
			{

				$id = htmlspecialchars($rows['id']);
				$userMail = htmlspecialchars($rows['userMail']);
				$userMessage = htmlspecialchars($rows['userMessage']);
		?>
				<div id="recentArticles">
					<div id="firstArticle" name="firstArticle">
						<h3 id="firstArticleHeadTitle">Email</h3>
						<center><?php echo $userMail;?></center>
						<h3 id="firstArticleHeadTitle">Message</h3>
						<center><?php echo $userMessage; ?></center>
						<center><a href="index.php?action=deleteMessage&messageId=<?= $rows['id'] ?>">Supprimer</a></center>
					</div>
				</div>
		<?php
			}
		?>

	<footer>
		<?php
			include('footer.php');
		?>
	</footer>
</body>
</html>
<?php

	//include('../../templates/adminManagements/editArticle/editArticle.php');
	//include('../../templates/adminManagements/adminManagement1/adminManagement1.php');

?>