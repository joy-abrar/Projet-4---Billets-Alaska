<html>
<head>
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
</head>

<body>

<?php
	include('menubar.php');
?>

<?php		
	while ($rows = $readMore -> fetch()) 
	{
?>

	<div id="recentArticles">
		<div id="firstArticle" name="firstArticle">
			<h3 id="firstArticleHeadTitle"><?php echo $rows['Title']; ?></h3>
			<hr id="firstArticleHeaderSeperationBloc">
			<p id="firstArticleParagraphe">	<?php echo $rows['Paragraph']; ?> </p>
			<hr id="firstArticleFooterSeperationBloc">
		</div>
		<p id="firstArticleDate">	Publié le <?php echo $rows['date']; ?> </p>			
	</div>

<?php
	}
?>


<div id="commentSection">
	<?php
	while ($rows2 = $readMoreComments -> fetch()) 
	{
	?>
		<div id="firstArticle" name="firstArticle">
			<h3 id="firstArticleHeadTitle"><?php echo $rows2['username']; ?></h3>
			<hr id="firstArticleHeaderSeperationBloc">
			<p id="firstArticleParagraphe">	<?php echo $rows2['comment']; ?> </p>
			<br>
			<p id="firstArticleParagraphe2">	<?php echo $rows2['createdate']; ?> </p>
			<hr>
		</div>
	<?php
		}
	?>
	<?php
		include('templates/commentBox/commentBox.php');
	?>
</div>

<?php
	include('footer.php');
?>
</body>
</html>