<head>
	<link rel="stylesheet" type="text/css" href="../../public/css/style.css">
</head>
<?php
	include('../../templates/basicTheme/menubar.php');
?>

<?php
	//echo $_GET['id'];
	$id = $_GET['id'];
	include('../../model/db/databaseConnection.php');
	$query = " DELETE FROM articles WHERE id = $id";
	$run = mysqli_query($connect , $query);
	
	$query2 = " DELETE FROM comments WHERE articleId = $id ";
	$run2 = mysqli_query($connect , $query2);
?>



<center>
	<h2>Votre Article a bien été supprimé</h2>
	<h4>Cliquez <a href="../../index.php?action=editArt">ici</a> Pour retourner sur la page des articles.</h4>
</center>
