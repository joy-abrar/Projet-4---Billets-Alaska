<?php
	//$sessionId = $_GET['sessionId'];
	include('templates/basicTheme/menubar.php');
	include('model/db/databaseConnection.php');
	$query = "SELECT * FROM articles ORDER BY id DESC LIMIT 1";
	$run = mysqli_query($connect , $query);
?>