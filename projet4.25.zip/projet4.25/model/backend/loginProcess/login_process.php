<?php

	//include('controller/controller_user.php');
	//include('controller/controller_admin.php');
	
	//$controls_user = new Controls_User();
	//$controls_admin = new Controls_Admin();

	$connection = mysqli_connect("localhost" , "root" , "" , "projet4");


	if (isset($_POST['loginSubmit'])) 
	{
		$id = $_POST['loginId'];
		$password = $_POST['loginPassword'];


		$query = "SELECT *FROM account WHERE login = '$id' AND password = '$password' " ;

		$run = mysqli_query($connection , $query);

		if ($run) 
			{
				if (mysqli_num_rows($run)>0) 
				{
					
					$controls_admin -> loggedIn();
				}

				else
				{
					echo '<div>Wrong ID/Password Inserted! Try Again!</div>';
				}
			}
	}
?>