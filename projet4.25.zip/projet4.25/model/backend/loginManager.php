<?php

	class loginManager
	{
		public function getLogin() // for accurate navigation in reading post pages (2/4) 
		{ 
			
			$connection = mysqli_connect("localhost" , "root" , "" , "projet4");
			
			if (isset($_POST['loginSubmit'])) 
			{
				$id = $_POST['loginId'];
				$password = $_POST['loginPassword'];
				$decryptedPassword = base64_encode($password);
				$password = $decryptedPassword;
				$query = "SELECT *FROM account WHERE login = '$id' AND password = '$password' " ;

				$run = mysqli_query($connection , $query);

				if ($run) 
					{
						if (mysqli_num_rows($run)>0) 
						{
							$_SESSION['admin_status'] = "loggedIn";
							if ($_SESSION['admin_status'] == "loggedIn") 
							{
								$controls_admin = new Controls_Admin;
								$controls_admin -> loggedIn();	
							}

							else if ($_SESSION['admin_status'] == "loggedOut") 
							{
								$controls_user -> homepage();
							}						
						}

						else
						{
							echo '<div>Wrong ID/Password Inserted! Try Again!</div>';
						}
					}
			}
		}

		public function getLogOut() // for accurate navigation in reading post pages (2/4) 
		{
			$_SESSION['admin_status'] == "loggedOut";
			header("location:./index.php");
		}

	}


?>