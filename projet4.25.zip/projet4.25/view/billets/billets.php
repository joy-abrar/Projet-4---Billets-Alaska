<?php
	include('templates/billets/menubar.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>

<body>
		<?php
			//while ($rows=mysqli_fetch_assoc($run)) 
			while($rows = $allPosts->fetch())
			{
				//var_dump($rows['id']);
				//die();
				
				$selectedId = $rows['id'];
				$totalPara = $rows['Paragraph'];
				$cutPara = implode(' ', array_slice(explode(' ' , $totalPara), 0,34));
				//echo "allArticles.php " . $selectedId;

		?>
	<div id="recentArticles">
		<div id="articleView">
			<div id="firstArticle" name="firstArticle">
				<h3 id="firstArticleHeadTitle"><?php echo $rows['Title']; ?></h3>
				<hr id="firstArticleHeaderSeperationBloc">
				<p id="firstArticleParagraphe">	<?php /*echo $rows['Paragraph'];*/ echo $cutPara ?> </p>
				<hr id="firstArticleFooterSeperationBloc">
				<p id="firstArticleDate"> Publié le <?php echo $rows['date']; ?> </p>
				<a href="index.php?action=viewMore&amp;selectedId= <?= $selectedId ?>">Voir Plus...</a>
				<p><?php echo $rows['commentsNb']." "."comments" ?></p>
			</div>		
		</div>
	</div>				
		<?php
			}
		?>

</body>
</html>
<?php
	include('templates/billets/footer.php');
?>