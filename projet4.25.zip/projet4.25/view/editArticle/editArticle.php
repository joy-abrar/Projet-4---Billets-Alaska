<?php
	include('menubar.php');
	include('../../model/db/databaseConnection.php');
	$query = "SELECT * FROM articles";
	$run = mysqli_query($connect , $query);
?>


<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../../public/css/style.css">
	<title>Articles From DataBase</title>
</head>
<body>


		<?php
			session_start();
			while ($rows=mysqli_fetch_assoc($run)) 
			{

				$_SESSION["idSelected"] = htmlspecialchars($rows['id']);
				$_SESSION["titleSelected"] = htmlspecialchars($rows['Title']);
				$_SESSION["paragraphSelected"] = htmlspecialchars($rows['Paragraph']);
		?>
				<div id="recentArticles">
					<div id="firstArticle" name="firstArticle">
						<h3 id="firstArticleHeadTitle"><?php echo $rows['Title'];?></h3>
						<h3 id="firstArticleHeadTitle">Publié le <?php echo $rows['date'];?></h3>
						<center>
							<a href="../../index.php?action=editThisArticle&amp;id=<?= $rows['id'] ?>&amp;title=<?= htmlspecialchars($rows['Title']) ?>&amp;para=<?= htmlspecialchars($rows['Paragraph']) ?>">EDIT</a>
							
							<a href="../../index.php?action=deleteThisArticle&amp;id=<?= htmlspecialchars($rows['id']) ?>&amp;title=<?= htmlspecialchars($rows['Title']) ?>&amp;para=<?= htmlspecialchars($rows['Paragraph']) ?>">DELETE</a>

						</center>
					</div>
				</div>
		<?php
			}
		?>
	</table>

	<footer>
		<?php
			include('footer.php');
		?>
	</footer>
</body>
</html>
<?php

	//include('../../templates/adminManagements/editArticle/editArticle.php');
	include('../../templates/adminManagements/adminManagement1/adminManagement1.php');

?>