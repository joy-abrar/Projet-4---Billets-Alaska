<?php
	include('model/db/databaseConnection.php');
	$query = "SELECT *FROM articles WHERE id = '$sessionId' ";
	$run = mysqli_query($connect , $query);
?>


		<?php
			while ($rows = mysqli_fetch_assoc($run)) 
			{
		?>
	<div id="recentArticles">
		<div id="firstArticle" name="firstArticle">
			<h3 id="firstArticleHeadTitle"><?php echo $rows['Title']; ?></h3>
			<hr id="firstArticleHeaderSeperationBloc">
			<p id="firstArticleParagraphe">	<?php echo $rows['Paragraph']; ?> </p>
			<hr id="firstArticleFooterSeperationBloc">
		</div>
		<p id="firstArticleDate">	Publié le <?php echo $rows['date']; ?> </p>
	</div>

<?php
	}
?>

<?php
					/*--------------------------------------- Comment Section ------------------------*/

	$query = "SELECT *FROM comments WHERE articleId = $sessionId  ";
	$run = mysqli_query($connect , $query);
?>

	<div id="recentArticles2">
		<center><h2><u>Commentaires</u></h2></center>
		<?php
			while ($rows = mysqli_fetch_assoc($run)) 
				{
					$rows['id'];
					$rows['comment'];
		?>
	
					<div id="firstArticle2" name="firstArticle">
						<h3 id="firstArticleHeadTitle"><?php echo $rows['username']; ?></h3>
						<hr id="firstArticleHeaderSeperationBloc">
						<p id="firstArticleParagraphe">	<?php echo $rows['comment']; ?> </p>
						<hr>
						<p id="firstArticleParagraphe">	<a href="">Signaler</a> </p>
					</div>

			<?php
				}
				include('templates/commentBox/commentBox.php');
			?>
	</div>

<?php
	//include('templates/commentBox/commentBox.php');
?>