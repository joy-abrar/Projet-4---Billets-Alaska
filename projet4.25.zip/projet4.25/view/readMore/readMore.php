<html>
<head>
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
</head>

<body>

<?php
	include('model/backend/lastArticleMore/lastArticleMore.php');		
	while ($rows = mysqli_fetch_assoc($run)) 
	{
?>

	<div id="recentArticles">
		<div id="firstArticle" name="firstArticle">
			<h3 id="firstArticleHeadTitle"><?php echo $rows['Title']; ?></h3>
			<hr id="firstArticleHeaderSeperationBloc">
			<p id="firstArticleParagraphe">	<?php echo $rows['Paragraph']; ?> </p>
			<hr id="firstArticleFooterSeperationBloc">
		</div>
		<p id="firstArticleDate">	Publié le <?php echo $rows['date']; ?> </p>			
	</div>

<?php
	}
?>

<?php
	include('model/db/databaseConnection.php');
	$query = "SELECT *FROM comments WHERE articleId = $sessionId  ";
	$run = mysqli_query($connect , $query);

?>
<?php
while ($rows = mysqli_fetch_assoc($run)) 
			{
				$rows['id'];
				$rows['comment'];
?>
	<div id="recentArticles">
		<div id="firstArticle" name="firstArticle">
			<h3 id="firstArticleHeadTitle"><?php echo $rows['username']; ?></h3>
			<hr id="firstArticleHeaderSeperationBloc">
			<p id="firstArticleParagraphe">	<?php echo $rows['comment']; ?> </p>
		</div>			
	</div>

<?php
	}
?>

<?php
	include('templates/commentBox/commentBox.php');
?>
</body>
</html>