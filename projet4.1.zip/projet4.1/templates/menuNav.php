<link rel="stylesheet" type="text/css" href="style2.css">

	
	<div id="navBar">
		<a id="menuNav" href="#">Accueil</a>
		<a id="menuNav2" href="#">Articles</a>
		<a id="menuNav2" href="#">Billets</a>
		<a id="menuNav2" href="../logout/logout.php">Deconnecter</a>
	</div>
