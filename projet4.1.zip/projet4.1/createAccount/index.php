<?php

	$conn = mysqli_connect("localhost" , "antorferdous" , "Allahuakbar_1" , "projet4");



?>


<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Create Account - Billets simple pour L'Alaska</title>
</head>

<body id="bodyBackground">


<?php

	if (isset($_POST['Submit'])) 
	{
		$firstname = $_POST['Firstname'];
		$lastname = $_POST['Lastname'];
		$username = $_POST['Username'];
		$email = $_POST['mail'];
		$password = $_POST['Pass'];
		

		$query = "insert into registration(FirstName , LastName , UserName , Email , Password)values('$firstname' , '$lastname' , '$username' , 
		'$email' , '$password')" ;

		$run = mysqli_query($conn , $query);

		if ($run) 
		{

			//$_SESSION['user_name'] = $username;
			header("location:../index.php");
		}

		else
		{
			echo "Not logged in! Please try again.";
			echo " error".mysqli_error($conn);
		}
	}

?>



	<form method="POST" action="">
		<div id="loginContent">
			<span id="loginContentText">First Name</span>
			<input id="loginContentBox" type="text" name="Firstname" required="">
			<span id="loginContentText">Last Name</span>
			<input id="loginContentBox" type="text" name="Lastname" required="">
			<span id="loginContentText">Username</span>
			<input id="loginContentBox" type="text" name="Username" required="">
			<span id="loginContentText">Email</span>
			<input id="loginContentBox" type="email" name="mail" required="">
			<span id="loginContentText">Password</span>
			<input id="loginContentBox" type="password" name="Pass" required="">
			<input id="loginContentLoginButton" type="submit" name="Submit" value="LOGIN">
		</div>
	</form>


</body>
</html>