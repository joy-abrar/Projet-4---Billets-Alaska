<?php
	session_start();
$username = "toto";
	$_SESSION['user_name'] = $username;

?>




<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Logged In</title>
</head>
<body id="backgroundHomepage">
<div>
	<?php
		include('../templates/menuNav.php');
	?>
</div>

	<center>
		<?php 
		echo "<h1> Welcome" . " " . $_SESSION['user_name'] . "</h1>";
		 ?>

	</center>

</body>
</html>