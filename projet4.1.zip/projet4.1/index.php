<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Login - Billets simple pour L'Alaska</title>
</head>


<?php

	$connection = mysqli_connect("localhost" , "antorferdous" , "Allahuakbar_1" , "projet4");



?>


<?php

	if (isset($_POST['submit'])) 
	{
		$email = $_POST['mail'];
		$password = $_POST['pass'];
		$username;

		$query = "select *from registration where Email = '$email' and Password = '$password' " ;

		$run = mysqli_query($connection, $query);

		if ($run) 
		{
			if (mysqli_num_rows($run)>0) 
			{
				$_SESSION['user_name'] = $username;
				header("location:home/homepage.php");
			}

			else
			{
				echo '<div>Wrong ID/Password Inserted! Try Again!</div>';
			}
		}
	}

?>



<body id="bodyBackground">
	<div id="TitleProject">
		<h1 id="titleParam">Billets Simple Pour L'Alaska</h1>
	</div>

	<form method="POST" action="">
		<div id="loginContent">
			<span id="loginContentText">Email</span>
			<input id="loginContentBox" type="text" name="mail">
			<span id="loginContentText">Password</span>
			<input id="loginContentBox" type="password" name="pass">
			<input id="loginContentLoginButton" type="submit" name="submit" value="LOGIN">
			<span>No Accounts? <a href="createAccount/index.php">Create now!</a></span>
		</div>
	</form>


</body>
</html>