<link rel="stylesheet" type="text/css" href="../public/css/style.css">

<?php

	include('../model/databaseConnection.php');
	include('../templates/menubar.php');
	include('../admin/admin.php');

?>



<body>

	<?php
		include('../templates/adminWelcome.php');
		include('../templates/adminFooter.php');
	?>

</body>




