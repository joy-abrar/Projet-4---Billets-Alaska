<?php
	include('../templates/menubar.php');
	include('../templates/allArticles.php');
	include('../templates/footer.php');
?>