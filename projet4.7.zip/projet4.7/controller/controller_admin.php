<?php

class Controls_Admin
{

	function loggedIn()
	{
		header("location:../view/adminLoggedIn.php");
	}

	function disconnect()
	{
		header("location:././index.php");
	}

	function editThisArticle()
	{
		header("location:././view/updatingArticleForm.php");
	}

}

?>