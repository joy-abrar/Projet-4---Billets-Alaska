<?php

	$connection = mysqli_connect("localhost" , "root" , "" , "projet4");

	$articleForSearching = $_SESSION['searchVariable'];

	$query = "SELECT *FROM articles WHERE Title = '$articleForSearching'";

	$run = mysqli_query($connection , $query);


if ($run) 
{
	if (mysqli_num_rows($run)>0) 
			{
				echo "article found !";
			}
}

else
{
	echo "article not found!";
}


?>