<?php
require_once('model/frontend/userManager.php');
require_once('model/frontend/postManager.php');
require_once('model/backend/loginManager.php');
class Controls_User
{	
	function startupRun()
	{
		include('./view/homepage.php');
	}

	function homepage()
	{

		$postManager = new postManager();
		$lastPost = $postManager -> getLastPost();
		require('view/homepage/homepage.php');
	}

	function biographie()
	{
		require('view/biographie/biographie.php');
	}


	function billets()
	{
		$postManager = new postManager();
		$allPosts = $postManager -> allPosts();
		require('view/billets/billets.php');
	}


	function contact()
	{
		$postManager = new postManager();
		$allPosts = $postManager -> allPosts();
		require('view/contact/contact.php');
	}

	function apropos()
	{
		require('view/aboutus/aboutus.php');
	}

	function login()
	{
		require('view/login/loginform.php');
		$loginManager = new loginManager();
		$getLogin = $loginManager -> getLogin();
	}

	function readMore($selectedId)
	{
		$sessionId = $selectedId;
		require('view/readMore/readMore.php');
		//require('view/readMore/readMore.php?sessionId=12');// . $sessionId);
		
	}

	function viewMore($selectedId)
	{
		$userManager = new userManager();
		$readPost = $userManager -> readPost($selectedId);
		require('view/viewMore/viewMore.php');
	}

	function postThisComment($sessionId, $username,$userComment)
	{
		$userManager = new userManager();
		$comment = $userManager -> postComment($sessionId, $username,$userComment);
		//require('./view/readMore/readMore.php');
		header('location:./index.php');
	}

	function signalComments($id)
	{
		$userManager = new userManager();
		$comment = $userManager -> signalComments($id);
		require('./view/viewMore/viewMore.php');
	}
}

?>