<?php
	require_once('model/Manager.php');

	class userManager extends Manager
	{
		public function postComment($sessionId, $username, $userComment) 
		{		 
			$db = $this->dbConnect();
			$sessionId = htmlspecialchars($sessionId);
			$usernameh = htmlspecialchars($username); 
			$userCommenth = htmlspecialchars($userComment);


			$comment = $db->prepare('INSERT INTO comments(articleId, username, comment) VALUES (?, ?, ?)');
			$affectedLines = $comment->execute(array($sessionId, $usernameh, $userCommenth));
			return $affectedLines;


			$numberOfComments = $db -> prepare('SELECT commentsNb FROM articles WHERE id = $sessionId');
			$affectedLines2 = $numberOfComments->execute(array($numberOfComments+1)); 
			return $affectedLines2;

		
			$insertNumberOfComments = $db->prepare('UPDATE articles SET (commentsNb) VALUES (?) WHERE id = $sessionId');
			$affectedLines3 = $insertNumberOfComments->execute(array($numberOfComments)); 
			return $affectedLines3;

		}

		public function controlMail($mail) // for accurate navigation in reading post pages (2/4) 
		{ 
			$db = $this->dbConnect();
			$mailCheck = $db->prepare('SELECT mail FROM account WHERE mail = ?');
			$mailVerif = $mailCheck->execute(array($mail)); 
			return $mailVerif;
		}

    	public function updateTempPwd($tempPwd, $mailtoAddress) 
    	{

	       	$db = $this->dbConnect();
	        $tempPassword = $db->prepare('UPDATE account SET password = ? WHERE mail = ?');
	        $randomInt = $tempPassword->execute(array($tempPwd, $mailtoAddress)); 
   		}

   		public function creatingArticleIntoDb($title, $para) 
		{
			$commentsNb = 0 ;
			$db = $this->dbConnect();
			$comment = $db->prepare('INSERT INTO articles(Title , Paragraph, commentsNb) VALUES (?, ?, ?)');
			$affectedLines = $comment->execute(array($title, $para, $commentsNb));
			return $affectedLines;
		}
		
		
		public function updatingArticleIntoDb($id , $givenArticleTitle, $givenArticleParagraph) 
		{
			$db = $this->dbConnect();
			$update = $db->prepare('UPDATE articles SET titre = ?, Paragraph = ? WHERE id = ?'); 
			$update->execute(array($givenArticleTitle, $givenArticleParagraph, $id));
		}

		public function signalComments($id) 
		{
			$db = $this->dbConnect();
			$update = $db->prepare('UPDATE comments SET signalc = 1 WHERE id = ?'); 
			$update->execute(array($id));
		}

		public function editAnArticle() 
		{
			$db = $this->dbConnect();
			$showArticles = $db -> prepare('SELECT * FROM articles');
			$showArticles->execute();
			return $showArticles;
		}

		public function showReportedComments() 
		{
			$signalcValue = 1 ;
			$db = $this->dbConnect();
			$show = $db->prepare('SELECT signalc FROM comments WHERE signalc = ?');
			$showReports = $show->execute(array($signalcValue));
			while($rows = $show -> fetch(PDO::FETCH_ASSOC))
			{
				$comment = $rows['comment'];
				echo $comment;
			}
			//return $showReports;

		}

		public function readPost($selectedId)
		{
			$db = $this->dbConnect();
			$query = $db->prepare('SELECT * FROM articles WHERE id = ?');
			$query->execute(array($selectedId));
			return $query;
		}
	}


?>