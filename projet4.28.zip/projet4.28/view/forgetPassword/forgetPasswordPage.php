<html>
<?php
	include('menubar.php');
?>

<head>
	<link rel="stylesheet" type="text/css" href="../../public/css/style.css">
</head>

<body>

<div id="loginPageBloc">
	<form method="POST" action="../../index.php?action=ctrlAdmin">
		<div id="loginBloc">
			<span><b>Adresse Mail</b></span>
			<input id="mailInput" type="text" name="mailInput"/>
			<br/>
			<br/><br/>
			<input id="loginbutton" type="submit" name="loginSubmit">
		</div>
	</form>
	<?php
		include('../../model/backend/loginManager.php');
	?>
</div>
</body>

<?php
	include('footer.php');
?>
</html>
