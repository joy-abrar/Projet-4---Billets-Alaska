<?php
	include('templates/billets/menubar.php');
	include('templates/billets/allArticles.php');
	include('templates/billets/footer.php');
?>