<html>
	<head>
	<link rel="stylesheet" type="text/css" href="../../public/css/style.css">
	</head>
	<body>
		<?php
			include('menubar.php');
			include('../../templates/adminManagements/adminWelcome/adminWelcome.php');
			include('../../templates/adminManagements/adminFooter/adminFooter.php');
		?>
	</body>
</html>



