
<head>
	<meta charset="utf-8">
	<meta name="viewport"  content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="./public/css/style.css">
	<title>Menu</title>
</head>
<body>

	<div id="menuParam">
		
		<div id="indexTitle">
			<a href="./././index.php" id="indexTitleParam">JEAN FORTEROCHE</a>
		</div>

		<div id="navBlock">
		<a href="./././index.php?action=accueil" class="navParam" id="accueil">ACCUEIL</a>
		<a href="./view/biographie.php" class="navParam" id="biographie">BIOGRAPHIE</a>
		<a href="./view/billets.php" class="navParam" id="billetSimple">BILLET SIMPLE</a>
		<a href="./view/billets.php" class="navParam" id="contact">CONTACT</a>
		</div>
	</div>

	<div id="welcomeBloc">
		<h1 id="welcomeMessage"><u>Bienvenue sur le site officiel de Jean Forteroche</u></h1>

		<div id="moreArticles">
			<h2 id="moreArticlesInfo">BILLETS SIMPLE POUR L'ALASKA. DECOUVREZ LES ROMANS PUBLIE EN CLIQUANT CI-DESSOUS</h2>
			
			<div id="moreArticlesButtons">	
				<a href="#" name="moreChapter" id="moreChapterButton">TOUS LES ARTICLES</a>
				<a href="#" name="aboutUs" id="moreAboutUs">A PROPOS DE NOUS</a>
			</div>
		</div>
	</div>



	<div id="recentArticles">
		<?php
			include('./model/articles.php');
		?>
		
	</div>


	<div id="footerPart">
		<?php
			include('./templates/footer.php');
		?>
	</div>


	</div>


</body>
</html>