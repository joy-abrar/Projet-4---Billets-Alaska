
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../public/css/style.css">
	<title>Show Reports</title>
</head>
<body>
	<?php
		include('menubar.php');
	?>
	<div id="recentArticles">
	<div id="firstArticle" name="firstArticle">
		<h3 id="firstArticleHeadTitle"><?php ?></h3>
		<h3 id="firstArticleHeadTitle">Publié le <?php ?></h3>
		<center>
			<a href="">EDIT</a>
			
			<a href="">DELETE</a>

		</center>
	</div>
	</div>
	<footer>
	<?php
		include('footer.php');
	?>
</footer>
</body>
</html>