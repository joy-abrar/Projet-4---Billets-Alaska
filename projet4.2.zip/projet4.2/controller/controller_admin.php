<?php

class Controls_Admin
{

	function loggedIn()
	{
		header("location:../view/adminLoggedIn.php");
	}

	function disconnect()
	{
		session_unset();
		header("location:././index.php");
	}

	function editThisArticle()
	{
		header("location:././templates/updatingArticle.php");
	}

}

?>