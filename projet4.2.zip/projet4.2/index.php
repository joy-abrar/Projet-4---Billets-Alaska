<?php 
include('controller/controller_user.php');
include('controller/controller_admin.php');

$controls_user = new Controls_User();
$controls_admin = new Controls_Admin();


		if (isset($_GET['action'])) 
		{
		
			if ($_GET['action'] == 'accueil') 
			{
				$controls_user -> homepage();
				
			}

			if ($_GET['action'] == 'biographie') 
			{
				$controls_user -> biographie();
				
			}

			if ($_GET['action'] == 'billets') 
			{
				$controls_user -> billets();
				 
			}

			if ($_GET['action'] == 'contact') 
			{
				$controls_user -> contact();
				
			}
		
			if ($_GET['action'] == 'all_articles') 
			{
				$controls_user -> billets();
			}

			if ($_GET['action'] == 'aboutus') 
			{
				$controls_user -> apropos();
			}

			if ($_GET['action'] == 'connect') 
			{
				$controls_user -> login();
			}

			if ($_GET['action'] == 'disconnect') 
			{
				$controls_admin -> disconnect();
			}


			if ($_GET['action'] == 'editThisArticle') 
			{
				$controls_admin -> editThisArticle();
			}
	

		}



		else
			{
				$controls_user -> homepage();
			}

?>