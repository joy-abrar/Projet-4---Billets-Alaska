<head>
	<link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>




<div id="footerPart">
	<div id="footerBloc">
			
			<div id="footerParts">
				<div id="footerAdministrationTitle">
					<h3 id="footerAdministration"><u>ADMINISTRATION</u></h3>	
					<div id="footerAdministrationContent">
						<a href="../index.php?action=connect" class="hyperlinkDecor">SE CONNECTER</a>
					</div>
				</div>	
			</div>

			
			<div id="footerParts">
				<div id="footerPlanTitle">
					<h3 id="footerPlan"><u>PLAN DU SITE</u></h3>
					<div id="footerPlanContent">
						<a href="./view/homepage.php?action=accueil" class="hyperlinkDecor">ACCUEIL</a>
						<a href="./view/biographie.php?action=biographie" class="hyperlinkDecor">BIOGRAPHIE</a>
						<a href="./view/billets.php?action=billets" class="hyperlinkDecor">BILLET SIMPLE</a>
					</div>
				</div>
			</div>


		<div id="footerParts">
			<div id="footerContactTitle">
				<h3 id="footerContact"><u>REJOIGNEZ-NOUS</u></h3>
				<div id="footerContactContent">
					<a href="" class="hyperlinkDecor">TWITTER</a>
					<a href="" class="hyperlinkDecor">INSTAGRAM</a>
					<a href="" class="hyperlinkDecor">FACEBOOK</a>
				</div>
			</div>
		</div>
	</div>
</div>