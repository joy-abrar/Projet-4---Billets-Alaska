<link rel="stylesheet" type="text/css" href="../public/css/style.css">


<form method="POST" action="">
	<div id="chosenButtonBloc">
			<div id="createAnArticle">
				<span><h2>Titre De Votre Article</h2></span>
				<input id="givenArticleTitle" type="text" name="givenArticleTitle">

				<span><h2>Your Article</h2></span>
				<textarea id="givenArticleParagraph" type="text" name="givenArticleParagraph"></textarea>
				<input id="createArticleSubmitButton" type="submit" name="createArticleSubmitButton">
			</div>
			
		</div>
</form>