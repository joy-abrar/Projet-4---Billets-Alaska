<div id="editTable">
	<div>
		<table style="width:100%">
		  <tr>
		    <th>ID</th>
		    <th>TITLE</th>
		    <th>PARAGRAPH</th>
		    <th>ACTION</th>
		  </tr>
		  <tr>
		    <td><?php echo $_SESSION['row0'] ?></td>
		    <td><?php echo $_SESSION['row1'] ?></td>
		    <td><?php echo $_SESSION['row2'] ?></td>
		    <td><a href="../index.php?action=editThisArticle">Edit</a></td>
		  </tr>
		</table>
	</div>
	
</div>