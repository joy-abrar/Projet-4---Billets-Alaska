<link rel="stylesheet" type="text/css" href="../public/css/style.css">


<div id="searchForm">
	<form method="POST" action="">
		<input id="searchbox" type="text" name="searchArticleBox" placeholder="Search By Your Article Name...">
		<input id="searchbutton" type="submit" name="searchArticleButton">

	</form>
</div>
