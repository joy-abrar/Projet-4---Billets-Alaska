
<head>
	<meta charset="utf-8">
	<meta name="viewport"  content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="./public/css/style.css">
	<title>Menu</title>
</head>
<body>

	<?php
		include('../templates/menubar.php');
		include('../templates/welcomeTheme.php');
		include('../templates/articles.php');
		include('../templates/footer.php');
	?>

			

</body>
</html>