<?php
	include('../templates/menubar.php');
	include('../templates/articles.php');
	include('../templates/footer.php');
?>