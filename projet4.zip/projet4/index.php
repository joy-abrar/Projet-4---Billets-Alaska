<?php 
	include('model/model.php');
	include('view/view.php');
?>
