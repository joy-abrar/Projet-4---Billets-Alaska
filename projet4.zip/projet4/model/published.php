<link rel="stylesheet" type="text/css" href="../public/css/style.css">
<div id="publishingBloc">
	<span>Votre Article à Bien éte Publié!</span>
</div>

