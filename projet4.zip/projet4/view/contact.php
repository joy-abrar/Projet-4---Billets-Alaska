<?php
	include('../templates/menubar.php');
	include('./templates/footer.php');
?>