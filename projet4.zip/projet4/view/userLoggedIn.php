<link rel="stylesheet" type="text/css" href="../public/css/style.css">

<?php

	$connect = mysqli_connect("localhost" , "antorferdous" , "Allahuakbar_1" , "projet4");
	include('../templates/menubar.php');
	include('../user/user.php');

?>



<body>
	<div id="welcomePage">
		<h1 id="">Bienvenue 
			<?php 
				echo $username ;  
		?>
			 
		</h1>
	</div>


	<div id="welcomePageManagement">
		<form id="createArticleForm" method="POST" action="">
			<button name="createArt" id="createArticleButton">CREATE AN ARTICLE</button>
		</form>
		<form id="editArticleForm" method="POST" action="">
			<button name="editArt" id="editArticleButton">EDIT AN EXISTING ARTICLE</button>
		</form>
	
	</div>

	<?php
		if (isset($_POST['createArt'])) 
		{
			include('../templates/createArticleForm.php');
		}


		if (isset($_POST['editArt'])) 
		{
			include('../templates/editArticleForm.php');
		}

	?>


	<?php
	if (isset($_POST['createArticleSubmitButton'])) 
		{
			$givenTitle = $_POST['givenArticleTitle'];
			$givenPara = $_POST['givenArticleParagraph'];

			$inserting = "INSERT INTO articles(Title , Paragraph) VALUES ('$givenTitle' , '$givenPara')" ;

			$query = mysqli_query($connect , $inserting);
		
			if ($query) 
			{
				include_once('../model/published.php');
			}
		}	
	?>


<div id="footerPart">
	<?php
		include('../templates/footer.php');
	?>
	
</div>

</body>




