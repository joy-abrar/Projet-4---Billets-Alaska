<?php
	$connect = mysqli_connect("localhost" , "antorferdous" , "Allahuakbar_1" , "projet4");

?>

<?php
	include('../templates/menubar.php');
	include('../templates/loginform.php');
?>



<?php

	if (isset($_POST['loginSubmit'])) 
	{
		$idInserted = $_POST['loginId'];
		$passwordInserted = $_POST['loginPassword'];

		$inserting = "select *from account where login = '$idInserted' and password = '$passwordInserted' " ;

		$query = mysqli_query($connect , $inserting);

		if (mysqli_num_rows($query) > 0) 
		{
			function success()
			{
				header('location:userLoggedIn.php');	
			}
			success();
		}

		else
		{
			function failed()
			{
				header('location:loggedInFailed.php');
			}
			failed();
		}

	}

?>

<div id="footerPart">
	<?php
		include('../templates/footer.php');
	?>
</div>
