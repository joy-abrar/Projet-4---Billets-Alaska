
<head>
	<link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>
	<div id="menuParam">
		
		<div id="indexTitle">
			<a href="../index.php" id="indexTitleParam">JEAN FORTEROCHE</a>
		</div>

		<div id="navBlock">
		<a href="../index.php" class="navParam" id="accueil">ACCUEIL</a>
		<a href="../view/biographie.php" class="navParam" id="biographie">BIOGRAPHIE</a>
		<a href="../view/billets.php" class="navParam" id="billetSimple">BILLET SIMPLE</a>
		<a href="../view/contact.php" class="navParam" id="contact">CONTACT</a>
		</div>
	</div>