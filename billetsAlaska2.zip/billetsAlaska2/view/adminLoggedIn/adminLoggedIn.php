<html>
	<head>
	<link rel="stylesheet" type="text/css" href="../../public/css/style.css">
	</head>
	<body>
		<?php
		
		if ($_GET['sessionStatus'] == "loggedIn") 
		{
			include('menubar.php');
			include('../../templates/adminManagements/adminWelcome/adminWelcome.php');
			include('../../templates/adminManagements/adminFooter/adminFooter.php');
		}

		else
		{
			echo "Veuilez-vous connectez d'abord!";
		}

		?>
	</body>
</html>



