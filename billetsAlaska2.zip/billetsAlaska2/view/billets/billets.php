<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>

<body>
	<?php
	include('templates/billets/menubar.php');
	?>

		<?php
			while($rows = $allPosts->fetch())
			{

				
				$selectedId = $rows['id'];
				$totalPara = $rows['Paragraph'];
				$cutPara = implode(' ', array_slice(explode(' ' , $totalPara), 0,34));
				//echo "allArticles.php " . $selectedId;

		?>
	<div id="recentArticles">
		<div id="articleView">
			<div id="firstArticle" name="firstArticle">
				<h3 id="firstArticleHeadTitle"><?php echo $rows['Title']; ?></h3>
				<hr id="firstArticleHeaderSeperationBloc">
				<p id="firstArticleParagraphe">	<?php /*echo $rows['Paragraph'];*/ echo $cutPara ?> </p>
				<hr id="firstArticleFooterSeperationBloc">
				<h4 id="firstArticleDate"> Publié le <?php echo $rows['date']; ?> </h4>
				<a href="index.php?action=viewMore&amp;selectedId= <?= $selectedId ?>">Voir Plus...</a>
				<p><?php echo $rows['commentsNb']." "."commentaires" ?></p>
			</div>		
		</div>
	</div>				
		<?php
			}
		?>

</body>
</html>
<?php
	include('templates/billets/footer.php');
?>