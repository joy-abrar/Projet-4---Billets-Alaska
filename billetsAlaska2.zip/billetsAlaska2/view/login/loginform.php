
<html>
<head>
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
</head>

<body>
<?php
	include('templates/loginform/menubar.php');
?>
<div id="loginPageBloc">
	<form method="POST" action="">
		<div id="loginBloc">
			<span><b>Identifiant</b></span>
			<input id="loginIdInput" type="text" name="loginId"/>
			<br/>
			<span><b>Mot De Passe</b></span>
			<input id="loginPasswordInput" type="password" name="loginPassword"/>
			<br/><br/>
			<input id="loginbutton" type="submit" name="loginSubmit">
		</div>
	</form>
	<center>
		<a href="index.php?action=forgetPassword">mot de passe oublié?</a>
	</center>
</div>

<?php
	//include('templates/loginform/footer.php');
?>
</body>
</html>


