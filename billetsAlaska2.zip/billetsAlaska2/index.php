<?php 
	require('controller/controller_user.php');
	require('controller/controller_admin.php');

	$controls_user = new Controls_User();
	$controls_admin = new Controls_Admin();


	if (isset($_GET['action'])) 
	{
		if ($_GET['action'] == 'accueil') 
		{
			$controls_user -> homepage();
		}

		if ($_GET['action'] == 'biographie') 
		{
			$controls_user -> biographie();		
		}

		if ($_GET['action'] == 'billets') 
		{
			$controls_user -> billets();			 
		}

		if ($_GET['action'] == 'contact') 
		{
			$controls_user -> contact();	
		}
	
		if ($_GET['action'] == 'all_articles') 
		{
			$controls_user -> billets();
		}

		if ($_GET['action'] == 'aboutus') 
		{
			$controls_user -> apropos();
		}

		if ($_GET['action'] == 'connect') 
		{
			$controls_user -> login();
		}

		if ($_GET['action'] == 'forgetPassword') 
		{
			$controls_admin -> forgetPswdPage();
		}
		
		if ($_GET['action'] == 'ctrlAdmin') 
		{
			$controls_admin -> controlMail($_POST['mailInput']);
		}

		if ($_GET['action'] == 'disconnect') 
		{
			$controls_admin -> disconnect();
		}

		if ($_GET['action'] == 'returnToArticles') 
		{
			$controls_user -> billets();
		}

		if ($_GET['action'] == 'readMore') 
		{
			$selectedId = $_GET['selectedId'];
			$controls_user -> readMore($selectedId);	
		}

		if ($_GET['action'] == 'viewMore') 
		{
			$selectedId = $_GET['selectedId'];
			$controls_user -> viewMore($selectedId);
		}

		/* -------------- EDITER UN ARTICLE SELECTIONNE PAR BOUTON EDITER --------------------*/
		if ($_GET['action'] == 'editThisArticle') 
		{
			//echo $_GET['id'];
			$id = $_GET['id'];
			$title = $_GET['title'];
			$paragraph = $_GET['para'];
			$controls_admin -> editThisArticle($id,$title,$paragraph);
		}

		/* -------------- SUPPRIMER UN ARTICLE SELECTIONNE PAR BOUTON DELETE --------------------*/
		if ($_GET['action'] == 'deleteThisArticle') 
		{
			$id = $_GET['id'];
			$controls_admin -> deleteThisArticle($id);
		}

		/* -------------- CONFIRMATION DE LA SUPPRESSION DE L'ARTICLE SELECTIONNEE -------------*/
		if ($_GET['action'] == 'deletingArticleFormConfirmed') 
		{
			$_GET['id'];
			$id = $_GET['id'];
			$controls_admin -> deletingArticleFormConfirmed($id);
		}

		/*--------------- ANNULATION DE LA SEPPRESSION DE L'ARTICLE SELECTIONNEE ---------------*/
		if ($_GET['action'] == 'deletingArticleFormDenied') 
		{
			$controls_admin -> deletingArticleFormDenied();
		}

		if ($_GET['action'] == 'postThisComment') 
		{
			$controls_user -> postThisComment($_GET['sessionId'], $_POST['username'], $_POST['userComment']); 
		}		
	
		/*-------------------- METTRE A JOUR L'ARTICLE EXISTANT------------------------------ */
		if ($_GET['action'] == 'updateMyArticle') 
		{
			$id = $_GET['id'];
			$givenArticleTitle = $_POST['givenArticleTitle'];
			$givenArticleParagraph = $_POST['givenArticleParagraph'];
			$controls_admin -> updateMyArticle($id, $givenArticleTitle, $givenArticleParagraph);
		}
		/*-----------------------BOUTON CREER UN ARTICLE DEPUIS ADMIN MANAGEMENT ---------------*/
		if ($_GET['action']=='createArt') 
		{
			$controls_admin -> createAnArticle();
		}
		/*-----------------------BOUTON EDITER UN ARTICLE EXISTANT DEPUIS ADMIN MANAGEMENT------*/
		if ($_GET['action']=='editArt') 
		{
			$controls_admin -> editAnArticle();
		}

		if ($_GET['action']=='viewMessages') 
		{
			$controls_admin -> viewMessages();
		}

		if ($_GET['action']=='deleteMessage') 
		{
			$messageId = $_GET['messageId'];
			$controls_admin -> deleteMessage($messageId);
		}

		if ($_GET['action']=='signalComments') 
		{
			$id = $_GET['id'];
			$articleId = $_GET['selectedId'];
			$controls_user -> signalComments($id,$articleId);
		}

		if ($_GET['action']=='reportComments') 
		{
			$controls_admin -> reportComments();
		}

		if ($_GET['action']=='removeReport') 
		{
			$id = $_GET['id'];
			$controls_admin -> removeReport($id);
		}

		if ($_GET['action']=='deleteReport') 
		{
			$id = $_GET['id'];
			$controls_admin -> deleteReport($id);
		}

		if ($_GET['action']=='postThisMessage') 
		{
			$userMail = $_POST['mail'];
			$userMessage = $_POST['userMessage'];
			$controls_user -> postThisMessage($userMail,$userMessage);
		}
		
	}

	else if (isset($_GET['createArticleSubmitButton'])) 
	{
		$givenArticleTitle = $_GET['givenArticleTitle'];
		$givenArticlePara = $_GET['givenArticleParagraph'];
		$controls_admin -> creatingArticleNow($givenArticleTitle , $givenArticlePara);
	}

	 	
	/*---------------------------SI RIEN DE CI-DESSOUS, ALLER A LA PAGE D'ACCUEIL----------- */
	else
		{
			$controls_user -> homepage();
		}

?>


