<?php
require_once('model/frontend/userManager.php');
require_once('model/frontend/postManager.php');
require_once('model/backend/loginManager.php');
class Controls_User
{	
	function startupRun()
	{
		include('./view/homepage.php');
	}

	function homepage()
	{

		$postManager = new postManager();
		$lastPost = $postManager -> getLastPost();
		require('view/homepage/homepage.php');
	}

	function biographie()
	{
		require('view/biographie/biographie.php');
	}


	function billets()
	{
		$postManager = new postManager();
		$allPosts = $postManager -> allPosts();
		require('view/billets/billets.php');
	}


	function contact()
	{
		$postManager = new postManager();
		$allPosts = $postManager -> allPosts();
		require('view/contact/contact.php');
	}

	function apropos()
	{
		require('view/aboutus/aboutus.php');
	}

	function login()
	{
		require('view/login/loginform.php');
		$loginManager = new loginManager();
		$getLogin = $loginManager -> getLogin();
		include('templates/loginform/footer.php');
	}

	function readMore($selectedId)
	{
		$sessionId = $selectedId;
		$userManager = new userManager();
		$readMore = $userManager -> readMore($selectedId);
		$readMoreComments = $userManager -> readMoreComments($selectedId);
		require('view/readMore/readMore.php');
		
	}

	function viewMore($selectedId)
	{
		$sessionId = $selectedId;
		$userManager = new userManager();
		$readPost = $userManager -> readPost($selectedId);
		$readPostComments = $userManager -> readPostComments($selectedId);
		require('view/viewMore/viewMore.php');
	}

	function postThisComment($sessionId, $username,$userComment)
	{
		$userManager = new userManager();
		$comment = $userManager -> postComment($sessionId, $username,$userComment);
		$updateCommentNumber = $userManager -> updateCommentNumber($sessionId);
		header('location: index.php?action=viewMore&selectedId='.$sessionId);
	}

	function signalComments($id,$articleId)
	{
		$userManager = new userManager();
		$comment = $userManager -> signalComments($id,$articleId);
		header('location: index.php?action=viewMore&selectedId='.$articleId);
	}

	function postThisMessage($userMail,$userMessage)
	{
		$userManager = new userManager();
		$comment = $userManager -> postThisMessage($userMail,$userMessage);
		require('templates/messagePosted/messagePosted.php');
	}
}

?>