<?php
	$username = "Jean Forteroche" ;
?>

<link rel="stylesheet" type="text/css" href="../../public/css/style.css">
<div id="welcomePage">
		<h1 id="">Bienvenue <?php echo $username; ?> </h1>
</div>

<div id="welcomePageManagement">
		<form id="createArticleForm" method="POST" action="../../index.php?action=createArt">
			<input name="createArt" id="createArticleButton" type="submit" value="CREER UN ARTICLE">
		</form>
		
		<form id="editArticleForm" method="POST" action="../../index.php?action=editArt">
			<input name="editArt" id="editArticleButton" type="submit" value="EDITER UN ARTICLE EXISTANT">
		</form>

		<form id="viewMessagesForm" method="POST" action="../../index.php?action=viewMessages">
			<input name="viewMessages" id="viewMessagesButton" type="submit" value="VOIR MESSAGES">
		</form>	
</div>
