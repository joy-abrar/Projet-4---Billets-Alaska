<?php
	session_start();
	$admin_status = $_SESSION['admin_status'];
	if ($admin_status == "loggedIn") 
	{
?>
		<!DOCTYPE html>
		<html>
		<head>
			<link rel="stylesheet" type="text/css" href="../../public/css/style.css">
			<title>Tiny - MCE</title>
		</head>
		<body>
			<?php
				include('menubar.php');
			?>
			<form method="POST" action="../../index.php?action=creatingArticleNow">
				<div id="chosenButtonBloc">
					<div id="createAnArticle">
						<span><h2>Titre De L'article</h2></span>
						<input type="text" id="givenArticleTitle" name="givenArticleTitle">

						<span><h2>Votre Article</h2></span>
						<textarea id="givenArticleParagraph" class="tinymce" name="givenArticleParagraph"></textarea>
						
						<input id="createArticleSubmitButton" type="submit" name="createArticleSubmitButton">
					</div>			
				</div>
			</form>

			<div id="goBackForm">
				<form id="goBackForm" method="POST" action="../../index.php?action=dashboard">
					<input id="goBackButton" type="submit" value="RETOUR">
				</form>
			</div>

		<?php
			include('footer.php');
		?>
		<script type="text/javascript" src="../tinymce/js/jquery.min.js"></script>
		<script type="text/javascript" src="../tinymce/plugin/tinymce/tinymce.min.js"></script>
		<script type="text/javascript" src="../tinymce/plugin/tinymce/init-tinymce.js"></script>
		</body>
		</html>

		<script type="text/javascript" src="tinymce/js/jquery.min.js"></script>
		<script type="text/javascript" src="tinymce/plugin/tinymce/tinymce.min.js"></script>
		<script type="text/javascript" src="tinymce/plugin/tinymce/init-tinymce.js"></script>
<?php
}

else
	{
		header("location:../../index.php?action=connect");
	}
?>
