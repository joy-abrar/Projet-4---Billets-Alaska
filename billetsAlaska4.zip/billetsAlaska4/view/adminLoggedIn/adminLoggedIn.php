<?php
	ini_set( "display_errors", 0);
	session_start();
	$admin_status = $_SESSION['admin_status']; 
?>
<html>
	<head>
	<link rel="stylesheet" type="text/css" href="../../public/css/style.css">
	</head>
	<body>
		<?php
		
			if ($admin_status == "loggedIn") 
			{

				include('menubar.php');
				include('../../templates/adminManagements/adminWelcome/adminWelcome.php');
				include('../../templates/adminManagements/adminFooter/adminFooter.php');
			}

			else
			{
				header("location:../../index.php?action=connect");
				//echo "Veuilez-vous connectez d'abord!";
			}
		?>
	</body>
</html>



