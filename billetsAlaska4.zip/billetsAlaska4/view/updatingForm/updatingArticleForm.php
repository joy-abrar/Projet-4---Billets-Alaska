<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="./public/css/style.css">
	<title>Tiny - MCE</title>
</head>
<body>
	<?php
		include('././templates/basicTheme/menubar.php');
	?>
	<form method="POST" action="./index.php?action=updateMyArticle&amp;id=<?= $id ?>">
	<div id="chosenButtonBloc">
		<div id="createAnArticle">
			<span><h2>Titre De Votre Article</h2></span>
			<input type="text" id="givenArticleTitle" name="givenArticleTitle" placeholder="Title..." value="<?php echo $title ; ?>">

			<span><h2>Your Article</h2></span>
			<textarea id="givenArticleParagraph" class="tinymce" name="givenArticleParagraph"> <?php echo $paragraph;?> </textarea>			
			<input id="createArticleSubmitButton" type="submit" name="createArticleSubmitButton">
		</div>			
	</div>
</form>

<div id="goBackForm">
	<form id="goBackForm" method="POST" action="index.php?action=dashboard">
		<input id="goBackButton" type="submit" value="RETOUR">
	</form>
</div>

<script type="text/javascript" src="././view/tinymce/js/jquery.min.js"></script>
<script type="text/javascript" src="././view/tinymce/plugin/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="././view/tinymce/plugin/tinymce/init-tinymce.js"></script>

<?php
	include('././templates/basicTheme/footer.php');
?>
</body>
</html>
