
<?php
  	echo '<center><h2>Votre article à bien été mis à jour. Cliquez <a href="../../index.php?action=editArt">ici</a> pour retourner à la page des articles!</h2></center>'; 
?>