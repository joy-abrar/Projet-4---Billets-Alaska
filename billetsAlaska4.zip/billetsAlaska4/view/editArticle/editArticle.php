<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
	<title>Articles From DataBase</title>
</head>
<body>


		<?php
			include('menubar.php');
		//	session_start();
			while($rows = $connect->fetch())
			{

				$_SESSION["idSelected"] = htmlspecialchars($rows['id']);
				$_SESSION["titleSelected"] = htmlspecialchars($rows['Title']);
				$_SESSION["paragraphSelected"] = htmlspecialchars($rows['Paragraph']);
		?>
				<div id="recentArticles">
					<div id="firstArticle" name="firstArticle">
						<h3 id="firstArticleHeadTitle"><?php echo $rows['Title'];?></h3>
						<h3 id="firstArticleHeadTitle">Publié le <?php echo $rows['date'];?></h3>
						<center>
							<a href="index.php?action=editThisArticle&amp;id=<?= $rows['id'] ?>&amp;title=<?= htmlspecialchars($rows['Title']) ?>&amp;para=<?= htmlspecialchars($rows['Paragraph']) ?>">EDITER </a> |
							
							<a href="index.php?action=deleteThisArticle&amp;id=<?= htmlspecialchars($rows['id']) ?>&amp;title=<?= htmlspecialchars($rows['Title']) ?>&amp;para=<?= htmlspecialchars($rows['Paragraph']) ?>">SUPPRIMER</a>

						</center>
					</div>
				</div>
		<?php
			}
		?>

		<div id="goBackForm">
			<form id="goBackForm" method="POST" action="index.php?action=dashboard">
				<input id="goBackButton" type="submit" value="RETOUR">
			</form>
		</div>

	<footer>
		<?php
			include('footer.php');
		?>
	</footer>
</body>
</html>
<?php

	//include('../../templates/adminManagements/editArticle/editArticle.php');
	//include('../../templates/adminManagements/adminManagement1/adminManagement1.php');

?>