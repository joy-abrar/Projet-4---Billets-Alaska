<?php

	include('databaseConnection.php');

	echo $_GET['username'];
	echo $_GET['userComment'];
	$username = $_GET['username'];
	$userComment = $_GET['userComment'];
	
	$query = "INSERT INTO comments (articleid, username, comment) VALUES ('1' , '$username' , '$userComment') ";
	$run = mysqli_query($connect , $query);

	if (mysqli_query($connect, $query)) 
	{
  		echo "Votre Commentaire a été Publié !";
  		header("location:../view/billets.php");
	} 
	else 
	{
  		echo "Error: " . $query . "<br>" . mysqli_error($connect);
	}


?>