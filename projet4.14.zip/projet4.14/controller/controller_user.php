<?php
//require_once('./model/frontend/userManager.php');

class Controls_User
{	
	function startupRun()
	{
		include('./view/homepage.php');
	}

	function homepage()
	{
		header('location:./view/homepage/homepage.php');
	}

	function biographie()
	{
		header('location:./view/biographie/biographie.php');
	}


	function billets()
	{
		header('location:./view/billets/billets.php');
	}


	function contact()
	{
		header('location:./view/contact/contact.php');
	}

	function apropos()
	{
		header('location:./view/aboutus/aboutus.php');
	}

	function login()
	{
		header('location:./view/login/loginform.php');
	}

	function readMore($selectedId)
	{
		$sessionId = $selectedId;
		
		header("location:./view/readMore/readMore.php?sessionId=" . $sessionId);
	}

	function viewMore($selectedId)
	{
		$sessionId = $selectedId ;
		header("location:./view/viewMore/viewMore.php?sessionId=" . $sessionId );
	}

	function postThisComment($postId, $username,$userComment)
	{
		$userManager = new userManager();
		$comment = $userManager -> postComment($postId, $username,$userComment);
		require('./view/readMore.php');
	}
}

?>