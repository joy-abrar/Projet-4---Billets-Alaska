<?php

class Controls_Admin
{

	function loggedIn()
	{
		header("location:../../view/adminLoggedIn/adminLoggedIn.php");
	}

	function disconnect()
	{
		header("location:././index.php");
	}

	function editThisArticle()
	{
		include('././view/updatingArticleForm.php');
	}

	function deleteThisArticle()
	{
		include('././view/deletingArticleForm.php');
	}

	function deletingArticleFormConfirmed()
	{
		header('location:././view/deletingArticleFormConfirmed.php');
	}

	function deletingArticleFormDenied()
	{
		header('location:././view/billets.php');
	}
}

?>