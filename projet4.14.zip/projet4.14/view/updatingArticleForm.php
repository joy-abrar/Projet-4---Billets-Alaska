<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="././public/css/style.css">
	<title>Tiny - MCE</title>
</head>
<body>

	<form method="POST" action="">
	<div id="chosenButtonBloc">
		<div id="createAnArticle">
			<span><h2>Titre De Votre Article</h2></span>
			<input type="text" id="givenArticleTitle" name="givenArticleTitle" placeholder="Title..." value="<?php var_dump($_GET['title']) ; ?>">

			<span><h2>Your Article</h2></span>
			<textarea id="givenArticleParagraph" class="tinymce" name="givenArticleParagraph"> <?php var_dump($_GET['para']) ;  ?> </textarea>			
			<input id="createArticleSubmitButton" type="submit" name="createArticleSubmitButton">
		</div>			
	</div>
</form>

<script type="text/javascript" src="tinymce/js/jquery.min.js"></script>
<script type="text/javascript" src="tinymce/plugin/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="tinymce/plugin/tinymce/init-tinymce.js"></script>

<?php
	if (isset($_POST['createArticleSubmitButton'])) 
	{
		
	}

?>
</body>
</html>
