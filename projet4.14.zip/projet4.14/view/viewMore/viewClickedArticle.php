<?php
	include('../model/databaseConnection.php');
	$query = "SELECT *FROM articles WHERE id = '$sessionId' ";
	$run = mysqli_query($connect , $query);
?>


		<?php
			while ($rows = mysqli_fetch_assoc($run)) 
			{
		?>
	<div id="recentArticles">
		<div id="firstArticle" name="firstArticle">
			<h3 id="firstArticleHeadTitle"><?php echo $rows['Title']; ?></h3>
			<hr id="firstArticleHeaderSeperationBloc">
			<p id="firstArticleParagraphe">	<?php echo $rows['Paragraph']; ?> </p>
			<hr id="firstArticleFooterSeperationBloc">
		</div>
		<p id="firstArticleDate">	Publié le <?php echo $rows['date']; ?> </p>			
		

	</div>

<?php
	}
?>

<?php
	include('../templates/commentBox.php');
?>