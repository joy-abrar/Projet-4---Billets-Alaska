<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../public/css/style.css">
	<title>VIEW MORE</title>
</head>
<body>
	<?php
		include('menubar.php');
		$sessionId = $_GET['sessionId'];
		echo "viewMore.php" . $sessionId;
		include('viewClickedArticle.php');
		include('footer.php');
	?>
</body>
</html>