<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport"  content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="../../public/css/style.css">
	<title>Menu</title>
</head>
<body>

	<?php
		include('../../templates/homepageView/menubar.php');
		include('../../templates/homepageView/welcomeTheme.php');
		include('../../templates/homepageView/lastArticle.php');
		include('../../templates/homepageView/footer.php');
		
	?>		
</body>
</html>