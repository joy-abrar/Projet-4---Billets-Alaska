<?php
	include('../../templates/adminManagements/createArticleForm/createArticleForm.php');
	include('../../templates/adminManagements/adminManagement1/adminManagement1.php');
?>

<script type="text/javascript" src="tinymce/js/jquery.min.js"></script>
<script type="text/javascript" src="tinymce/plugin/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="tinymce/plugin/tinymce/init-tinymce.js"></script>

