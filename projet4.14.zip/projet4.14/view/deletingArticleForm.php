<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="././public/css/style.css">
	<title>Tiny - MCE</title>
</head>
<body>

	<form method="POST" action="">
	<center>
	<div id="chosenButtonBloc">
		<h2>Voulez-Vous Vraiment Supprimer Cet Article?</h2>
		<a href="././index.php?action=deletingArticleFormConfirmed">Oui</a>
		<a href="../index.php?action=deletingArticleFormDenied">Non</a>			
	</div>
	</center>
	</form>

<script type="text/javascript" src="tinymce/js/jquery.min.js"></script>
<script type="text/javascript" src="tinymce/plugin/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="tinymce/plugin/tinymce/init-tinymce.js"></script>

<?php
	if (isset($_POST['createArticleSubmitButton'])) 
	{
		
	}

?>
</body>
</html>
