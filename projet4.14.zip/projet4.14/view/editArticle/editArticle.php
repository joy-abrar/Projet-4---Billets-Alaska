<link rel="stylesheet" type="text/css" href="../public/css/style.css">
<?php

	include('../../templates/adminManagements/editArticle/editArticle.php');
	include('../../templates/adminManagements/adminManagement1/adminManagement1.php');

?>