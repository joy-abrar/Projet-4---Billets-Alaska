<?php
	require_once('./model/backend/Manager.php');

	class userManager extends Manager
	{
		public function postComment($postId, $username, $userComment) 
		{		 
			$db = $this->dbConnect();
			$usernameh = htmlspecialchars($username); 
			$userCommenth = htmlspecialchars($userComment); 
			$comment = $db->prepare('INSERT INTO comments(articleId, username, comment) VALUES (?, ?, ?)'); 
			$affectedLines = $comment->execute(array($postId, $usernameh, $userCommenth)); 
			return $affectedLines; 
		}
	}


?>