<link rel="stylesheet" type="text/css" href="../../public/css/style.css">
<div id="welcomePage">
		<h1 id="">Bienvenue 
			<?php 
				echo $username ;  
		?>
			 
		</h1>
	</div>

<div id="welcomePageManagement">
		<form id="createArticleForm" method="POST" action="">
			<input name="createArt" id="createArticleButton" type="submit" value="CREATE AN ARTICLE">
		</form>
		<form id="editArticleForm" method="POST" action="">
			<input name="editArt" id="editArticleButton" type="submit" value="EDIT AN EXISTING ARTICLE">
		</form>	
</div>



<?php
	include('../../templates/adminManagements/adminManagement1/adminManagement1.php');
?>