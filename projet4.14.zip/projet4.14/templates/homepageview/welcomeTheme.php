<div id="welcomeBloc">
		<h1 id="welcomeMessage"><u>Bienvenue sur le site officiel de Jean Forteroche</u></h1>

		<div id="moreArticles">
			<h2 id="moreArticlesInfo">BILLETS SIMPLE POUR L'ALASKA. DECOUVREZ LES ROMANS PUBLIE EN CLIQUANT CI-DESSOUS</h2>
			
			<div id="moreArticlesButtons">	
				<a href="../../index.php?action=all_articles" name="moreChapter" id="moreChapterButton">TOUS LES ARTICLES</a>
				<a href="../../index.php?action=aboutus" name="aboutUs" id="moreAboutUs">A PROPOS DE NOUS</a>
			</div>
		</div>
	</div>