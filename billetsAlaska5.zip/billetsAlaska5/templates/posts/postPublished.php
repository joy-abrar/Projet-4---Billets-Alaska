<link rel="stylesheet" type="text/css" href="../../public/css/style.css">

<div>
	<center><h4 style="color:darkgreen;">Votre Article à été Publié !</h4></center>
	<center>
			<form id="goBackForm" method="POST" action="../../index.php?action=dashboard">
				<input id="goBackButton" type="submit" value="RETOUR">
			</form>
		</div>
	</center>

</div>