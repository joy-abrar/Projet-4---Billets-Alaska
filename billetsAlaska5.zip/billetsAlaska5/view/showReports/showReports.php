
<!DOCTYPE html>
<html>
<head>
	<title>Show Reports</title>
</head>
<body>
	<?php
		include('adminMenubar.php');
		while ($rows = $commentsReported -> fetch()) 
		{
			$id = $rows['id'];
	?>
		<div id="reportedArticles">
			<div id="firstArticle" name="firstArticle">
				<h3 id="firstArticleHeadTitle"><?php echo $rows['username'] ?></h3>
				<h3 id="firstArticleHeadTitle"><?php echo $rows['comment'] ?></h3>
				<center id="reportDecisions">
					<a href="./index.php?action=removeReport&amp;id=<?= $id ?>">Enlever</a>
					
					<a href="./index.php?action=deleteReport&amp;id=<?= $id ?>">Supprimer</a>

				</center>
			</div>
		</div>
	<?php
		}
	?>

	<div id="goBackForm">
		<form id="goBackForm" method="POST" action="index.php?action=dashboard">
			<input id="goBackButton" type="submit" value="RETOUR">
		</form>
	</div>

	<footer>
	<?php
		include('adminFooter.php');
	?>
	</footer>
</body>
</html>