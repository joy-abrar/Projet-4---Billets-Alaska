<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport"  content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
	<title>Menu</title>
</head>
<body>
	<?php
		if ($_SESSION['admin_status'] == "loggedIn") 
		{
			include('templates/homepageView/adminMenubar.php');
			include('templates/homepageView/welcomeTheme.php');
			include('templates/homepageView/lastArticle.php');
			include('templates/homepageView/adminFooter.php');
		}

		else
		{
			include('templates/homepageView/menubar.php');
			include('templates/homepageView/welcomeTheme.php');
			include('templates/homepageView/lastArticle.php');
			include('templates/homepageView/footer.php');
		}
	?>		
</body>
</html>