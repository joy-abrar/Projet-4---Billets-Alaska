<head>
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
</head>




<div id="footerPart">
	<div id="footerBloc">
			
			<div id="footerParts">
				<div id="footerAdministrationTitle">
					<h3 id="footerAdministration"><u>ADMINISTRATION</u></h3>	
					<div id="footerAdministrationContent">
						<a href="../../index.php?action=disconnect" class="hyperlinkDecor">SE DECONNECTER</a>
					</div>
				</div>	
			</div>

			
			<div id="footerParts">
				<div id="footerPlanTitle">
					<h3 id="footerPlan"><u>PLAN DU SITE</u></h3>
					<div id="footerPlanContent">
						<a href="../../index.php?action=accueil" class="hyperlinkDecor">ACCUEIL</a>
						<a href="../../index.php?action=biographie" class="hyperlinkDecor">BIOGRAPHIE</a>
						<a href="../../index.php?action=billets" class="hyperlinkDecor">BILLETS SIMPLE</a>
					</div>
				</div>
			</div>


		<div id="footerParts">
			<div id="footerContactTitle">
				<h3 id="footerContact"><u>REJOIGNEZ-NOUS</u></h3>
				<div id="footerContactContent">
					<a href="https://www.twitter.com" class="hyperlinkDecor">TWITTER</a>
					<a href="https://www.instagram.com" class="hyperlinkDecor">INSTAGRAM</a>
					<a href="https://www.facebook.com" class="hyperlinkDecor">FACEBOOK</a>
				</div>
			</div>
		</div>
	</div>
</div>