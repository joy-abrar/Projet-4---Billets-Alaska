<?php
if ($_SESSION['admin_status'] == "loggedIn") 
{
	include('templates/biographie/adminMenubar.php');
	include('templates/biographie/bioJeanForteroche.php');
	include('templates/biographie/adminFooter.php');	
}

else
{
	include('templates/biographie/menubar.php');
	include('templates/biographie/bioJeanForteroche.php');
	include('templates/biographie/footer.php');
}


?>