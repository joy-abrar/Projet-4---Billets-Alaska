<?php
?>
<head>
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">	
</head>
	<div id="menuParam">
		
		<div id="indexTitle">
			<a href="index.php?action=accueil" id="indexTitleParam">JEAN FORTEROCHE</a>
		</div>

		<div id="navBlock">
		<a href="../../index.php?action=accueil" class="navParam" id="accueil">ACCUEIL</a>
		<a href="../../index.php?action=biographie" class="navParam" id="biographie">BIOGRAPHIE</a>
		<a href="../../index.php?action=billets" class="navParam" id="billetSimple">BILLETS</a>
		<a href="../../index.php?action=dashboard" class="navParam" id="billetSimple">TABLEAU DU BORD</a>
		<a href="../../index.php?action=reportComments" class="navParam" id="notifications"><i class="fa fa-bell" aria-hidden="true"></i></a>
		</div>
	</div>

