<head>
	<link rel="stylesheet" type="text/css" href="../../public/css/style.css">
</head>
<?php
	include('../../templates/basicTheme/menubar.php');
?>

<center>
	<h2>Votre Article a bien été supprimé</h2>
	<h4>Cliquez <a href="../../index.php?action=editArt">ici</a> Pour retourner sur la page des articles.</h4>
</center>
