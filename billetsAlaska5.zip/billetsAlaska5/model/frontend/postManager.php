<?php
	require_once('model/Manager.php');

	class postManager extends Manager
	{
		public function getLastPost() // for accurate navigation in reading post pages (2/4) 
		{ 
			$db = $this->dbConnect(); 
			$req = $db->prepare('SELECT * FROM articles ORDER BY id DESC LIMIT 1'); 
			$req->execute(); 
			$lastPost = $req->fetch(); 
			return $lastPost; 
		}

		public function allPosts() // for accurate navigation in reading post pages (2/4) 
		{ 
			$db = $this->dbConnect(); 
			$req = $db->prepare('SELECT * FROM articles ORDER BY id DESC'); 
			$req->execute();
			return $req; 
		}

	}


?>