<?php 
	include('controller/controller_user.php');
	include('controller/controller_admin.php');

	$controls_user = new Controls_User();
	$controls_admin = new Controls_Admin();


	if (isset($_GET['action'])) 
	{
	
		if ($_GET['action'] == 'accueil') 
		{
			$controls_user -> homepage();
		}

		if ($_GET['action'] == 'biographie') 
		{
			$controls_user -> biographie();
			
		}

		if ($_GET['action'] == 'billets') 
		{
			$controls_user -> billets();
			 
		}

		if ($_GET['action'] == 'contact') 
		{
			$controls_user -> contact();
			
		}
	
		if ($_GET['action'] == 'all_articles') 
		{
			$controls_user -> billets();
		}

		if ($_GET['action'] == 'aboutus') 
		{
			$controls_user -> apropos();
		}

		if ($_GET['action'] == 'connect') 
		{
			$controls_user -> login();
		}

		if ($_GET['action'] == 'disconnect') 
		{
			$controls_admin -> disconnect();
		}

		if ($_GET['action'] == 'returnToArticles') 
		{
			$controls_user -> billets();
		}

		if ($_GET['action'] == 'readMore') 
		{
			$selectedId = $_GET['selectedId'];
			$controls_user -> readMore($selectedId);
			
		}

		if ($_GET['action'] == 'viewMore') 
		{
			$selectedId = $_GET['selectedId'];
			$controls_user -> viewMore($selectedId);
		}


		if ($_GET['action'] == 'editThisArticle') 
		{
			//echo $_GET['id'];
			$id = $_GET['id'];
			$title = $_GET['title'];
			$paragraph = $_GET['para'];
			$controls_admin -> editThisArticle($id,$title,$paragraph);

		}

		if ($_GET['action'] == 'deleteThisArticle') 
		{
			$id = $_GET['id'];
			$controls_admin -> deleteThisArticle($id);
		}

		if ($_GET['action'] == 'deletingArticleFormConfirmed') 
		{
			$_GET['id'];
			$id = $_GET['id'];
			$controls_admin -> deletingArticleFormConfirmed($id);
		}

		if ($_GET['action'] == 'deletingArticleFormDenied') 
		{
			$controls_admin -> deletingArticleFormDenied();
		}

		if ($_GET['action'] == 'postThisComment') 
		{
			//$sessionId = $_GET['sessionId'];
			$controls_user -> postThisComment($_GET['sessionId'], $_POST['username'], $_POST['userComment']); 
		}		
	
		if ($_GET['action'] == 'updateMyArticle') 
		{
			$id = $_GET['id'];
			$givenArticleTitle = $_POST['givenArticleTitle'];
			$givenArticleParagraph = $_POST['givenArticleParagraph'];
			$controls_admin -> updateMyArticle($id, $givenArticleTitle, $givenArticleParagraph);
		}
	}


	else
		{
			$controls_user -> homepage();
		}

?>