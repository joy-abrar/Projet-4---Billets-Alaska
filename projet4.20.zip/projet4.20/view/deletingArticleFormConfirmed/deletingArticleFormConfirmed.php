<head>
	<link rel="stylesheet" type="text/css" href="../../public/css/style.css">
</head>
<?php
	include('../../templates/basicTheme/menubar.php');
?>

<?php
	//var_dump($_GET['id']);
	//echo $_GET['id'];
	$id = $_GET['id'];
	include('../../model/db/databaseConnection.php');
	$query = " DELETE FROM articles WHERE 'id' = '$id'";
	$run = mysqli_query($connect , $query);

?>



<center>
	<h2>Votre Article a bien été supprimé</h2>
	<h4>Cliquez <a href="../../index.php">ici</a> Pour retourner sur la page d'accueil</h4>
</center>
