<link rel="stylesheet" type="text/css" href="../../public/css/style.css">

<?php

	include('../../model/db/databaseConnection.php');
	include('menubar.php');
	include('../../model/backend/admin/admin.php');

?>



<body>

	<?php
		include('../../templates/adminManagements/adminWelcome/adminWelcome.php');
		include('../../templates/adminManagements/adminFooter/adminFooter.php');
	?>

</body>




