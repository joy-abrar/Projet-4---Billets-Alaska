<?php

require_once('model/frontend/userManager.php');
require_once('model/frontend/postManager.php');
require_once('model/backend/loginManager.php');

class Controls_Admin
{

	function loggedIn()
	{
		header("location:view/adminLoggedIn/adminLoggedIn.php");
	}

	function disconnect()
	{
		header("location:./index.php");
	}

	function editThisArticle($id,$title,$paragraph)
	{
		include('././view/updatingForm/updatingArticleForm.php');
	}

	function deleteThisArticle($id)
	{
		$id;
		include('././view/deletingArticleForm/deletingArticleForm.php');
	}

	function deletingArticleFormConfirmed($id)
	{
		$id = $id;
		echo $id;
		header('location:././view/deletingArticleFormConfirmed/deletingArticleFormConfirmed.php?id='.$id);
	}

	function deletingArticleFormDenied()
	{
		header('location:././view/billets.php');
	}

	function updateMyArticle($id, $givenArticleTitle, $givenArticleParagraph)
	{
		$id = $id;
		$givenArticleTitle = $givenArticleTitle ;
		$givenArticleParagraph = $givenArticleParagraph;
 		
		header('location:././view/updatedArticle/updatedArticle.php?id='.$id . '&givenArticleTitle='.$givenArticleTitle.'&givenArticleParagraph='.$givenArticleParagraph);
	}
}

?>