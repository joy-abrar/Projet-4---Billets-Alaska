<?php
	require_once('model/Manager.php');

	class userManager extends Manager
	{
		public function postComment($sessionId, $username, $userComment) 
		{		 
			$db = $this->dbConnect();
			$sessionId = htmlspecialchars($sessionId);
			$usernameh = htmlspecialchars($username); 
			$userCommenth = htmlspecialchars($userComment); 
			$comment = $db->prepare('INSERT INTO comments(articleId, username, comment) VALUES (?, ?, ?)'); 
			$affectedLines = $comment->execute(array($sessionId, $usernameh, $userCommenth)); 
			return $affectedLines; 
		}
	}


?>