	<?php
		$query = "SELECT *FROM articles WHERE id = '$sessionId' ";
		$run = mysqli_query($connect , $query);
	?>