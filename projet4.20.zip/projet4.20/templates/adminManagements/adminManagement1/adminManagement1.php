<?php
	include('../../model/databaseConnection.php');
?>

<?php
		if (isset($_POST['createArt'])) 
		{
			header("location:../createArticle/createArticle.php");
		}


		if (isset($_POST['createArticleSubmitButton'])) 
		{
			$givenTitle = $_POST['givenArticleTitle'];
			$givenPara = $_POST['givenArticleParagraph'];

			$inserting = "INSERT INTO articles(Title , Paragraph) VALUES ('$givenTitle' , '$givenPara')" ;

			$query = mysqli_query($connect , $inserting);
		
			if ($query) 
			{
				header("location:../../templates/posts/postPublished.php");
			}

			else
			{
				 echo "Error updating record: " . $connect->error;
				//header("location:../../templates/posts/failedPublish.php");
			}
		}



		if (isset($_POST['editArt'])) 
		{
			header("location:../../view/editArticle/editArticle.php");	
		}
?>



