<?php
	include('../model/databaseConnection.php');
	$query = "SELECT * FROM articles";
	$run = mysqli_query($connect , $query);
?>



<head>
	<link rel="stylesheet" type="text/css" href="./public/css/style.css">
	<title>Articles From DataBase</title>
</head>
<body>
	
	<?php
		while ($rows = mysqli_fetch_assoc($run)) 
		{
			$articleId = $rows['id'];
	?>
	
	<div id="recentArticles">
		<div id="firstArticle" name="firstArticle">
			<h3 id="firstArticleHeadTitle"><?php echo $rows['Title']; ?></h3>
			<hr id="firstArticleHeaderSeperationBloc">
			<p id="firstArticleParagraphe">	<?php echo $rows['Paragraph']; ?> </p>
			<hr id="firstArticleFooterSeperationBloc">
		</div>		
		<p id="firstArticleDate"> Publié le <?php echo $rows['date']; ?> </p>
		<div>
			<form method="GET" action="">
				<input type="submit" name="seecomments" value="comments">
			</form>
		</div>
	</div>				
	<?php

			if (isset($_GET['seecomments'])) 
			{
				$_SESSION['articleId'] = $articleId ;
				include("readComments.php");
			}
		}
	?>


</body>
