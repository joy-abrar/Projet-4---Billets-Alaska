<?php 
	class Manager 
	{ 
		protected function dbConnect() 
		{ 
			/*
			$host_name = 'db5000617501.hosting-data.io'; 
			$database = 'dbs586280'; 
			$user_name = 'dbu724449'; 
			$password = 'Allahuakbar_11'; 
			*/
			$host_name = 'localhost'; 
			$database = 'projet4'; 
			$user_name = 'root'; 
			$password = ''; 
			$db = null; 
			try 
			{ 
				$db = new PDO("mysql:host=$host_name; dbname=$database", $user_name, $password);
				return $db; 
			} 
			catch (PDOException $e) 
			{ 
				echo "Erreur!: " . $e->getMessage() . "<br/>"; 
				die(); 
			} 
		} 
	}

