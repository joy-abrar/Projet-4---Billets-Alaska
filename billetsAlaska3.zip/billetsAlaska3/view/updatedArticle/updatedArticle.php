<?php
	/*include('../../model/db/databaseConnection.php');
	$givenArticleTitle = $_GET['givenArticleTitle'];
	$givenArticleParagraph = $_GET['givenArticleParagraph'];
	$id = $_GET['id'];
	

	$query = " UPDATE articles SET  Title = '$givenArticleTitle', Paragraph = '$givenArticleParagraph' WHERE id = '$id' ";
	$run = mysqli_query($connect , $query);
	
	if ($connect -> query($query) === TRUE) 
	{
	*/
  		echo '<center><h2>Votre article à bien été mis à jour. Cliquez <a href="../../index.php?action=editArt">ici</a> pour retourner à la page des articles!</h2></center>';
	
  	/*
	} 
	else
	{

  		echo "Error updating record: " . $connect->error;
	
	}
	*/

?>