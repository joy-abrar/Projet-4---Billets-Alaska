<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
	<title>VIEW MORE</title>
</head>
<body>
	<?php
		include('menubar.php');
	?>


	<?php
		while ($rows = $readPost -> fetch()) 
		{
			$selectedId = $rows['id'];
	?>
	<div id="recentArticles">
		<div id="firstArticle" name="firstArticle">
			<h3 id="firstArticleHeadTitle"><?php echo $rows['Title']; ?></h3>
			<hr id="firstArticleHeaderSeperationBloc">
			<p id="firstArticleParagraphe">	<?php echo $rows['Paragraph']; ?> </p>
			<hr id="firstArticleFooterSeperationBloc">
		</div>
		<p id="firstArticleDate">	Publié le <?php echo $rows['date']; ?> </p>
	</div>

<?php
	}
?>

	<div id="commentSection">
		<center><h2><u>Commentaires</u></h2></center>
		<?php
			while ($rows2 = $readPostComments -> fetch()) 
				{
		?>
	
					<div id="firstArticle2" name="firstArticle">
						<h3 id="firstArticleHeadTitle"><?php echo $rows2['username']; ?></h3>
						<hr id="firstArticleHeaderSeperationBloc">
						<p id="firstArticleParagraphe">	<?php echo $rows2['comment']; ?> </p>
						<br>
						<p id="firstArticleParagraphe2">	<?php echo $rows2['createdate']; ?> </p>
					<?php
						if ($rows2['signalc'] == 0) 
						{
					?>						
						<p id="firstArticleParagraphe">	<a href="index.php?action=signalComments&id=<?=$rows2['id']?>&selectedId=<?=$selectedId ?> ">Signaler</a></p>
						<hr>
						<?php
					}
						?>
					</div>
					<?php
						if ($rows2['signalc'] == 1) 
						{
					?> 
					<center><p>Signalé</p></center>
					<?php
						}
					?>
		<?php
				}
				include('templates/commentBox/commentBox.php');
		?>
	</div>
	<?php
		include('footer.php');
	?>
</body>
</html>