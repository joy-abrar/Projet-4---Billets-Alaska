<link rel="stylesheet" type="text/css" href="public/css/style.css">

<div>
	<center><h4 style="color:darkgreen;">Votre Message à été Envoyé !</h4></center>
	<center><h3 style="color:darkgreen;">Cliquez <a href="index.php">ICI</a> pour retourner à la page d'accueil.</h2></center>
</div>